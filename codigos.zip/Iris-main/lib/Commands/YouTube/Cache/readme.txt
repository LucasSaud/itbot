------
1. Aqui serão armazenados temporariamente os arquivos baixados no comando de YouTube.
2. Here is the folder that files downloaded from the YouTube command will be temporarily stored.
3. Aquí está la carpeta en la que se almacenarán temporalmente los archivos descargados del comando de YouTube.
------
1. Jamais desligue seu PC durante um download e evite o abuso dos comandos de download.
2. Never turn off your PC during a download and avoid abusing download commands.
3. Nunca apagues tu PC durante una descarga y evita abusar de los comandos de descarga.
------