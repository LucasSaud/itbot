-------
1. As sessões são armazenadas neste local, escaneie o código QR novamente quando as pastas estiverem pesando mais de 500 megabytes ou sua sessão estiver com lags.
2. Sessions are stored in this location, scan the QR code again when folders are weighing more than 500 megabytes or your session is experiencing lags.
3. Las sesiones se almacenan en esta ubicación, escanee el código QR nuevamente cuando las carpetas pesen más de 500 megabytes o cuando su sesión se vuelva lenta.
-------