------
1. Os backups serão inseridos nesta pasta.
2. The backups will be inserted at this folder.
3. Los backups se insertarán en esta carpeta.
------
1. Para corrigir erros de inicialização referentes a databases, basta extrair os arquivos na pasta correta e substituir os mesmos.
2. To fix initialization errors referring to databases, simply extract the files in the correct folder and replace them.
3. Para corregir errores de inicialización referentes a databases, simplemente extraiga los archivos en la carpeta correcta y reemplácelos.
------