const MAX_ITERATIONS = 1e7;
const pows = Array.from({ length: 32 }, (_, i) => 2 ** i);

function countIdenticalBits(a, b) {
  return pows.reduce((count, pow) => {
    return (a & pow) === (b & pow) ? count + 1 : count;
  }, 0);
}

function flipRandomBit(a) {
  const bitToFlip = Math.pow(2, Math.floor(Math.random() * 32));
  return a ^ bitToFlip;
}

function murmurize(a) {
  a ^= a >>> 16;
  a = (a * 0x85ebca6b) >>> 0;
  a ^= a >>> 13;
  a = (a * 0xc2b2ae35) >>> 0;
  a ^= a >>> 16;
  return a >>> 0;
}

function test(threshold) {
  const startTime = performance.now(); // Medir o tempo inicial

  const seen = new Set();
  let count = 0;
  let value = Math.floor(Math.random() * 4294967296); // Número inteiro aleatório de 32 bits

  for (let iteration = 0; iteration < MAX_ITERATIONS; iteration++) {
    const newValue = flipRandomBit(value);
    const sameBits = countIdenticalBits(murmurize(value), murmurize(newValue));

    if (!seen.has(newValue) && sameBits > threshold) {
      count++;
    }

    seen.add(newValue);
    value = newValue;
  }

  const endTime = performance.now(); // Medir o tempo final
  const executionTime = endTime - startTime; // Tempo de execução em milissegundos

  console.log(`Tempo de execução: ${executionTime} ms`);
  console.log(`Pelo menos ${(count * 100) / MAX_ITERATIONS}% obtiveram ${threshold} bits alterados a cada vez`);
}

test(16);
